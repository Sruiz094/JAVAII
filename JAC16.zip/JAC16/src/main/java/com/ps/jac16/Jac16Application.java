package com.ps.jac16;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Jac16Application {

	public static void main(String[] args) {
		SpringApplication.run(Jac16Application.class, args);
	}

}
