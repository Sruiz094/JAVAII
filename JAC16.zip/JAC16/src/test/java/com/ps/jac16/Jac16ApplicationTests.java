package com.ps.jac16;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Jac16ApplicationTests {

	@Test
	void contextLoads() {
	}

}
